The files contained within this zip can be used to configure pfSense and ADSync tool with setting used in our build. Please consult the practice guide Part C for specific version information.



pfSense
Interfaces - interfaces-config-pfSense.localdomain-20150402160851.xml
NAT - nat-config-pfSense.localdomain-20150402160838.xml
Firewall - filter-config-pfSense.localdomain-20150402160823.xml


ADSync Tool
nccoe.local.xml
hmdsbb.xml